from django.test import TestCase
from django.urls import reverse
from .models import StickyNotes


class StickyNotesModelTest(TestCase):

    def setUp(self):
        self.note = StickyNotes.objects.create(
            title='Test StickyNotes',
            content='This is a sticky note'
        )

    def test_stickynote_has_title(self):
        stickynote = StickyNotes.objects.get(id=self.note.id)
        self.assertEqual(stickynote.title, 'Test StickyNotes')

    def test_stickynote_has_content(self):
        stickynote = StickyNotes.objects.get(id=self.note.id)
        self.assertEqual(stickynote.content, 'This is a sticky note')

    def test_stickynote_str_method(self):
        self.assertEqual(str(self.note), 'Test StickyNotes')


class StickyNotesViewTest(TestCase):

    def setUp(self):
        self.note = StickyNotes.objects.create(
            title='Test StickyNotes',
            content='This is a sticky note'
        )

    def test_stickynotes_list_view(self):
        response = self.client.get(reverse('stickynotes_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test StickyNotes')

    def test_stickynote_details_view(self):
        response = self.client.get(reverse('stickynote_details', args=[self.note.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test StickyNotes')
        self.assertContains(response, 'This is a sticky note')

    def test_create_stickynote_view(self):
        response = self.client.post(reverse('notes_create'), {
            'title': 'New Sticky Note',
            'content': 'This is a new note.'
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(StickyNotes.objects.filter(title='New Sticky Note').exists())

    def test_edit_stickynote_view(self):
        response = self.client.post(reverse('notes_edit', args=[self.note.id]), {
            'title': 'Updated Title',
            'content': 'Updated content.'
        })
        self.assertEqual(response.status_code, 302)
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Updated Title')
        self.assertEqual(self.note.content, 'Updated content.')

    def test_delete_stickynote_view(self):
        response = self.client.post(reverse('notes_delete', args=[self.note.id]))
        self.assertEqual(response.status_code, 302)
        self.assertFalse(StickyNotes.objects.filter(id=self.note.id).exists())
