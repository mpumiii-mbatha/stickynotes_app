'''Importing django and model module'''
from django import forms
from .models import StickyNotes


class NotesForm(forms.ModelForm):
    """
    Form for creating and editing sticky notes

    Fields:
    - title: CharField for sticky note title.
    - content: Textfield for the sticky note content.

    Meta class:
    - Defines the model to use and the fields included.

    :param forms.ModelForm: Django's ModelForm class.
    """
    class Meta:
        model = StickyNotes
        fields = ['title', 'content']
