'''Modules imported'''
from django.shortcuts import render, get_object_or_404, redirect
from .models import StickyNotes
from .forms import NotesForm


def stickynotes_list(request):
    """
    View to display a list of sticky notes.

    :param request: HTTP request object.
    :return: Rendered template with a list of posts.
    """

    # pylint: disable=no-member
    sticky_notes = StickyNotes.objects.all()

    # Creating context
    context = {
        "sticky_notes": sticky_notes,
        "page_title": "Notes",
        }

    return render(request, "stickynotes/stickynotes_list.html", context)


def stickynote_details(request, pk):
    """
    View to display details of a selected sticky note.

    :param request: HTTP request object.
    :param pk: Primary key of the post.
    :return: Rendered template with details of the selected note.
    """
    stickynote = get_object_or_404(StickyNotes, pk=pk)
    return render(request, "stickynotes/stickynote_details.html",
                  {"stickynote": stickynote})


def notes_create(request):
    """
    View to create a new sticky note.

    :param request: HTTP request object.
    :return: Rendered template for create a new sticky note.
    """
    form = None

    if request.method == "POST":
        form = NotesForm(request.POST)
        if form.is_valid():
            stickynote = form.save(commit=False)
            stickynote.save()
            return redirect("stickynotes_list")

        else:
            form = NotesForm()

    return render(request, "stickynotes/stickynote_form.html",
                  {"form": form})


def notes_edit(request, pk):
    """
    View to edit a sticky note.

    :param request: HTTP request object.
    :param pk: Primary key of the note to be edited.
    :return: Rendered template for editing the specified note.

    """
    stickynote = get_object_or_404(StickyNotes, pk=pk)
    if request.method == "POST":
        form = NotesForm(request.POST, instance=stickynote)
        if form.is_valid():
            stickynote = form.save(commit=False)
            stickynote.save()
            return redirect("stickynotes_list")
    else:
        form = NotesForm(instance=stickynote)
    return render(request, "stickynotes/stickynote_form.html", {"form": form})


def notes_delete(request, pk):  # pylint: disable=unused-argument
    """
    View to delete an existing sticky note.

    :param request: HTTP request object.
    :param pk: Primary key of the sticky note to be deleted.
    :return: Redirect to the sticky note list after deletion.
    """
    stickynote = get_object_or_404(StickyNotes, pk=pk)
    stickynote.delete()
    return redirect("stickynotes_list")
