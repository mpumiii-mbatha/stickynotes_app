'''Modules imported'''
from django.contrib import admin
from .models import StickyNotes

admin.site.register(StickyNotes)
