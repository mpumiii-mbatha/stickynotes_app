'''Importing models Module'''
from django.db import models


class StickyNotes(models.Model):
    """Model representing bulletin board stickynotes

    Fields:
    -user: ForeignKey
    -title: Charfield
    -content: Textfield
    -created_at: DateTimeField
    -edited_at: DateTimeField

    Methods:
    -__str__: Returns a string representation of the
    sticky note, showing the title

    :param models.Model: Django's base model class
    """
    title = models.CharField(max_length=80)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    edited_at = models.DateTimeField(auto_now=True)

    # Defining a ForeingKey for a user's relationship

    def __str__(self):
        return str(self.title) or "Untitled"
