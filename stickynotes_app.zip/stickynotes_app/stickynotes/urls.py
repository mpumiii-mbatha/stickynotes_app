from django.urls import path
from . import views

urlpatterns = [
    # path('', views.stickynotes_list, name='stickynotes_list'),

    path('', views.stickynotes_list, name='stickynotes_list'),

    path('create/', views.notes_create, name='notes_create'),

    path('<int:pk>/details/', views.stickynote_details,
         name='stickynote_details'),

    path('<int:pk>/edit/', views.notes_edit, name='notes_edit'),

    path('<int:pk>/delete/', views.notes_delete, name='notes_delete'),
]
